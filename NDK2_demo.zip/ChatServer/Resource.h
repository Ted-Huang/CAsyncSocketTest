//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ChatServer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHATSERVER_DIALOG           102
#define IDS_CANNOT_START                102
#define IDS_STOPPED                     103
#define IDS_STARTED                     104
#define IDS_PING_RECEIVED               105
#define IDS_PING_ALL_USERS              106
#define IDS_USER_JOIN                   112
#define IDS_USER_QUIT                   113
#define IDS_PING_USER                   114
#define IDS_BIG_MESSAGE                 115
#define IDS_SERVER_CLOSE_USER           116
#define IDS_ERROR_RECEIVING_MESSAGE     117
#define IDS_ERROR_SENDING_MESSAGE       118
#define IDR_MAINFRAME                   128
#define IDC_BUTTON_START                1000
#define IDC_EDIT_MESSAGES               1002
#define IDC_LIST_USERS                  1003
#define IDC_BUTTON_PING_USER            1004
#define IDC_BUTTON_DISCONNECT_USER      1005
#define IDC_BUTTON_PING_ALL_USERS       1006
#define IDC_BUTTON_DISCONNECT_ALL_USERS 1007
#define IDC_EDIT_PORT                   1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
